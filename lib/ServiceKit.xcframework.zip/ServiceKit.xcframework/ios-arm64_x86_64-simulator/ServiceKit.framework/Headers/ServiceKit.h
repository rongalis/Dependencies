//
//  ServiceKit.h
//  ServiceKit
//
//  Created by srikanth on 10/31/22.
//

#import <Foundation/Foundation.h>

//! Project version number for ServiceKit.
FOUNDATION_EXPORT double ServiceKitVersionNumber;

//! Project version string for ServiceKit.
FOUNDATION_EXPORT const unsigned char ServiceKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ServiceKit/PublicHeader.h>


